# MEZAN Attendance — Free APK Builder

This project packages the existing MEZAN Attendance LIVE web app into an Android APK.

## Important
- The existing Supabase database is not changed.
- The existing Cloudflare LIVE app is not changed.
- The APK opens the current HTTPS LIVE app:
  `https://delicate-dawn-6bb7.kashiffajar786.workers.dev`
- Camera and location permissions are included.
- This workflow builds a free **debug APK** using GitHub Actions.
- No Supabase secret key is included.

## Build for free
1. Create a GitHub repository (public is the simplest free option).
2. Upload the contents of this folder to the repository.
3. Open **Actions**.
4. Select **Build MEZAN Attendance APK**.
5. Run **Build workflow**.
6. When it finishes successfully, open the workflow run and download the artifact named **MEZAN-Attendance-APK**.
7. Extract the artifact and install `app-debug.apk` on Android.

## Local Android Studio build
Open this folder in Android Studio and run the `app` configuration. Android Studio/Gradle will build the same debug APK.

## Package ID
`com.mezan.executivetower.attendance`
