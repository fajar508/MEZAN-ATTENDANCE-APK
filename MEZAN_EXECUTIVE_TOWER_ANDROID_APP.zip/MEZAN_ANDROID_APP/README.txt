MEZAN EXECUTIVE TOWER - Android APK wrapper

This project opens the existing secure HTTPS MEZAN attendance web app inside an Android WebView.
The WebView is configured for JavaScript, camera and GPS/geolocation so selfie attendance and office geofence can work.
Build: GitHub Actions -> Build MEZAN APK -> artifact MEZAN-EXECUTIVE-TOWER-APK.
